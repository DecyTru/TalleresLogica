/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller;

/**
 *
 * @author 503
 */
public class Ejercicios {
    public static void mein (String [] args){
        double a= 3+(8*5)-(6/3);
        System.out.println("Resultado "+a);
       
        /*Ejercicio 2*/
        double b= (2.5*2*3)-(4/2)+8;
        System.out.println("Resultado "+b);
        
        /*Ejercicio 3*/
        
    }
    
}
